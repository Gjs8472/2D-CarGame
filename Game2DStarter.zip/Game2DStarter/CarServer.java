import java.net.*;
import java.io.*;
import java.util.*;

public class CarServer{
   
   // Network
   private ServerSocket sSocket = null;
   public static final int SERVER_PORT = 3000;
   
   // Array list
   ArrayList<CarPosition> arrayPos = new ArrayList<CarPosition>();
   ArrayList<ObjectOutputStream> car = new ArrayList<ObjectOutputStream>();
   
   int index = 0;
   
   public CarServer(){
      Server server = new Server();
      server.start();
   }
   
   class Server extends Thread{
   
      public void run(){
         try{
            sSocket = new ServerSocket(SERVER_PORT);
            
            while(true){
               Socket cSocket = null;
               cSocket = sSocket.accept();
               
               Client client = new Client(cSocket);
               client.start();
               
               System.out.println("Connected");
            }
         }
         catch(IOException ioe){
            System.out.println("IOException1: " + ioe);
         }
      }
   
   }
   
   class Client extends Thread{
   
      // Socket
      private Socket cSocket = null;
      
      public Client(Socket cSocket){
         this.cSocket = cSocket;
      }
      
      public void run(){
         ObjectOutputStream oos = null;
         ObjectInputStream ois = null;
         
         try{
            System.out.println("Creating Streams");
            oos = new ObjectOutputStream((cSocket.getOutputStream()));
            ois = new ObjectInputStream((cSocket.getInputStream()));
            
            System.out.println("Adding oos to array");
            
            car.add(oos);
            
            System.out.println("Added oos to car & writing object");
            
            oos.writeObject((Integer)index);
            index++;
            
            System.out.println("Wrote object & flushing");
            
            oos.flush();
            
            while(true){
               Object obj = ois.readObject();
               
               if(obj instanceof CarPosition){
                  CarPosition pos = (CarPosition)obj;
                  
                  arrayPos.add(pos);
                  System.out.println(arrayPos.toString());
                  
                  for(ObjectOutputStream ooS: car){
                     System.out.println("Inside for loop");
                     if(ooS != oos){
                        System.out.println("Sending info to clients");
                        ooS.writeObject(pos);
                        ooS.flush();
                     }
                  }
               }
            }
         }
         catch(IOException ioe){
            System.out.println("IOException2: " + ioe);
         }
         catch(ClassNotFoundException cnfe){
            System.out.println("ClassNotFoundException: " + cnfe);
         }
      }
   
   }
   
   public static void main(String[] args){
      new CarServer();
   }

}