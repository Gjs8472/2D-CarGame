import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.stage.*;
import javafx.geometry.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class CarServer extends Application{
   
   // Attributes
   private Stage stage;
   private Scene scene;
   
   // VBox
   VBox root = new VBox(8);
   
   // Text area
   TextArea taLog = new TextArea();
   
   // Network
   private ServerSocket sSocket = null;
   public static final int SERVER_PORT = 3000;
   
   // Array list
   ArrayList<CarPosition> arrayPos = new ArrayList<CarPosition>();
   ArrayList<ObjectOutputStream> car = new ArrayList<ObjectOutputStream>();
   
   int index = 0;
   
   // Main
   public static void main(String[] args){
      launch(args);
   }
   
   /*
    * Start method
    * called via launsh
   */
   public void start(Stage _stage){
      stage = _stage;
      stage.setTitle("Game2D Server");
      
      taLog.setPrefHeight(350);
      
      root.getChildren().add(taLog);
      
      stage.setOnCloseRequest(
         new EventHandler<WindowEvent>(){
            public void handle(WindowEvent evt){
               System.exit(0);
            }
         }
      );
      
      scene = new Scene(root, 400, 350);
      stage.setScene(scene);
      stage.show();
      
      Server server = new Server();
      server.start();
   }
   
   /*
    * Server class
    * Handles the connection to the client/s
   */
   class Server extends Thread{
   
      public void run(){
         try{
            sSocket = new ServerSocket(SERVER_PORT);
            
            while(true){
               Socket cSocket = null;
               cSocket = sSocket.accept();
               
               Client client = new Client(cSocket);
               client.start();
               
               System.out.println("Connected");
            }
         }
         catch(IOException ioe){
            System.out.println("IOException1: " + ioe);
         }
      }
   
   }
   
   /*
    * Client class
    * Sends and receives information about the client
   */
   class Client extends Thread{
   
      // Socket
      private Socket cSocket = null;
      
      public Client(Socket cSocket){
         this.cSocket = cSocket;
      }
      
      public void run(){
         ObjectOutputStream oos = null;
         ObjectInputStream ois = null;
         
         try{
            taLog.appendText("Creating Streams" + "\n");
            oos = new ObjectOutputStream((cSocket.getOutputStream()));
            ois = new ObjectInputStream((cSocket.getInputStream()));
            
            taLog.appendText("Adding oos to array" + "\n");
            
            car.add(oos);
            
            taLog.appendText("Added oos to car & writing object" + "\n");
            
            oos.writeObject((Integer)index);
            index++;
            
            taLog.appendText("Wrote object & flushing" + "\n");
            taLog.appendText("Client: " + index + "\n\n");
            
            oos.flush();
            
            while(true){
               Object obj = ois.readObject();
               
               if(obj instanceof CarPosition){
                  CarPosition pos = (CarPosition)obj;
                  
                  arrayPos.add(pos);
                  System.out.println(arrayPos.toString());
                  
                  for(ObjectOutputStream ooS: car){
                     System.out.println("Inside for loop");
                     if(ooS != oos){
                        System.out.println("Sending info to clients");
                        ooS.writeObject(pos);
                        ooS.flush();
                     }
                  }
               }
            }
         }
         catch(IOException ioe){
            System.out.println("IOException2: " + ioe);
         }
         catch(ClassNotFoundException cnfe){
            System.out.println("ClassNotFoundException: " + cnfe);
         }
      }
   
   }

}