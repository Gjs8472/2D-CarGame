import java.io.Serializable;

public class CarPosition implements Serializable{
   
   // Serializability
   private static final long serialVersionUID = 01L;
   
   private int posX;
   private int posY;
   private int rot;
   private int carId;
   
   public CarPosition(int x, int y, int rot, int carId){
      this.posX = x;
      this.posY = y;
      this.rot = rot;
      this.carId = carId;
   }
   
   public int getPosX(){
      return this.posX;
   }
   
   public int getPosY(){
      return this.posY;
   }
   
   public int getRot(){
      return this.rot;
   }
   
   public int getCarId(){
      return this.carId;
   }
   
   public String toString(){
      return "X: " + getPosX() + ", Y: " + getPosY() + ", ROT: " + getRot();
   }

}