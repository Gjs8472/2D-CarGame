import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.animation.*;
import java.io.*;
import java.util.*;
import javafx.scene.input.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.net.*;
import javafx.scene.paint.Color;
import javafx.scene.effect.*;

//XML DOM PARSER
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.xml.sax.*;

/** 
 * Game2DSTARTER with JavaFX and Threads
   Valentines edition
   TODO: car opacity on the white area
*/

public class Game2D extends Application{
   
   // Window attributes
   private Stage stage;
   private Scene scene;
   private VBox root;
   
   private static String[] args;
   
   private final static String ICON_IMAGE = "car1.png";  // file with icon for a racer
   
   private int iconWidth;                       // width (in pixels) of the icon
   private int iconHeight;                      // height (in pixels) or the icon
   private int maskWidth;
   private int maskHeight;
   
   private CarRacer racer = null;               // array of racers
   private Image carImage =  null;
   
   private boolean forward;
   private boolean backward;
   private boolean right;
   private boolean left;
   
   private BufferedImage bImage = null;
   private BufferedImage mask = null;
   
   public double carSpeed;
   public double carSteeringAngle = 0;
   
   // Network
   public static final int SERVER_PORT = 3000;
   private Socket socket = null;
   
   private ObjectInputStream ois = null;
   private ObjectOutputStream oos = null;
   
   private File f = null;

   private AnimationTimer timer;                // timer to control animation
   
   // Array list for cars
   ArrayList<CarRacer> arrayCars = new ArrayList<CarRacer>();
   
   // Car index
   int carIndex;
   
   // main program
   public static void main(String[] _args){
      args = _args;
      launch(args);
   }
   
   // start() method, called via launch
   public void start(Stage _stage){
      // stage seteup
      stage = _stage;
      stage.setTitle("Game2D");
      stage.setOnCloseRequest(
         new EventHandler<WindowEvent>(){
            public void handle(WindowEvent evt){
               System.exit(0);
            }
         }
      );
      
      // root pane
      root = new VBox();
                 
      // create an array of Racers (Panes) and start
      initializeScene();
   }

   // start the race
   public void initializeScene(){
      
      // Make an icon image to find its size
      try{
         carImage = new Image(new FileInputStream(ICON_IMAGE));
      }
      catch(Exception e){
         System.out.println("Exception: " + e);
         System.exit(1);
      }
      
      try{
         f = new File("newMap1.png");
         mask = ImageIO.read(f);
      }catch(IOException ioe){
        System.out.println("IOException 4: " + ioe);
      }
      
      // Get image size
      iconWidth = (int)carImage.getWidth();
      iconHeight = (int)carImage.getHeight();
      maskWidth = (int)mask.getWidth();
      maskHeight = (int)mask.getHeight();
      
      //XML
      XMLSettings xmlWorker = new XMLSettings("GameSettings.xml");
      //xmlWorker.writeXML(); // Call this only if GameSettings.xml does not exist
      xmlWorker.readXML();
      
      for(int i = 0;i < 2;i++){
         racer = new CarRacer(i);
         
         racer.setTranslateX(730);
         racer.setTranslateY(120);
         
         root.getChildren().add(racer);
         root.setId("pane");
         arrayCars.add(racer);
      }
      
      // display the window
      scene = new Scene(root, 1500, 728); // 1500, 728
      scene.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
      stage.setScene(scene);
      stage.show();
      
      System.out.println("Starting race...");
      
      scene.setOnKeyPressed(
         new EventHandler<KeyEvent>(){
            public void handle(KeyEvent ke){
               switch (ke.getCode()){
                  case UP:
                     carSpeed = 3;
                     forward = true;
                     break;
                  case DOWN:
                     carSpeed = -3;
                     backward = true;
                     break;
                  case LEFT:
                     carSteeringAngle = 2;
                     left  = true;
                     break;
                  case RIGHT:
                     carSteeringAngle = -2;
                     right  = true;
                     break;
               }
            }
         }
      );
      scene.setOnKeyReleased(
         new EventHandler<KeyEvent>(){
            public void handle(KeyEvent ke){
               switch (ke.getCode()){
                  case UP:
                     carSpeed = 0;
                     forward = false;
                     break;
                  case DOWN:
                     carSpeed = 0;
                     backward = false;
                     break;
                  case LEFT:
                     carSteeringAngle = 0;
                     left  = false;
                     break;
                  case RIGHT:
                     carSteeringAngle = 0;
                     right  = false;
                     break;
               }
            }
         }
      );
      
      // Use an animation to update the screen
      timer = new AnimationTimer(){
            public void handle(long now){
               racer.update();
            }
         };
      
      // TimerTask to delay start of race for 2 seconds
      TimerTask task = new TimerTask(){
            public void run(){
               timer.start();
            }
         };
      Timer startTimer = new Timer();
      long delay = 1000L;
      startTimer.schedule(task, delay);
      
      // Connection method
      connect();
   }
   
   /** 
      Racer creates the race lane (Pane) and the ability to 
      keep itself going (Runnable)
   */
   protected class CarRacer extends Pane{
      
      private int racePosX = 0;          // x position of the racer
      private int racePosY = 0;          // x position of the racer
      private int raceROT = 0;          // x position of the racer
      private ImageView aPicView;   // a view of the icon ... used to display and move the image
      
      int carId;
      
      public CarRacer(int carId){
         this.carId = carId;
         carId++;
         
         String imageOfCars = "car" + carId + ".png";
         
         // Draw the icon for the racer
         aPicView = new ImageView(imageOfCars);
         this.getChildren().addAll(aPicView);
      }
   
      /** 
         update() method keeps the thread (racer) alive and moving.
      */
      public void update(){
         aPicView.setTranslateX(racePosX);
         aPicView.setTranslateY(racePosY);
         aPicView.setRotate(raceROT);
         
         double deltaX = carSpeed * Math.cos(raceROT * 3.14 / 180.0);
         racePosX += deltaX;
         
         double deltaY = carSpeed * Math.sin(raceROT * 3.14 / 180.0);
         racePosY += deltaY;
         
         double deltaROT = (carSpeed / 50) * Math.tan(carSteeringAngle * 3.14 / 180.0);
         raceROT += deltaROT;
         
         if(forward == true) racePosX += deltaX;
         if(backward == true) racePosY += deltaY;
         if(left == true) raceROT -= 4;
         if(right == true) raceROT += 4;
         
         // Get pixel value
         int p = mask.getRGB(730,120);
         
         //get alpha
         int a = (p>>24) & 0xff;
         
         //get red
         int r = (p>>16) & 0xff;
         
         //get green
         int g = (p>>8) & 0xff;
         
         //get blue
         int b = p & 0xff;
              
         CarPosition pos = new CarPosition(racePosX, racePosY, raceROT, carId);
         
         try{
            oos.writeObject(pos);
            oos.flush();
         }
         catch(IOException ioe){
            System.out.println("IOException 2: " + ioe);
         }
         
         try{
            Thread.sleep(10);
         }
         catch(InterruptedException ie){
            System.out.println("InterruptedException: " + ie);
         } 
      }  // end update()
      
   }  // end inner class Racer
   
   /*
    * Connect method
    * This method connects the client to the server to the server
   */
   public void connect(){
      try{
         socket = new Socket("127.0.0.1", SERVER_PORT);
         
         ois = new ObjectInputStream(socket.getInputStream());
         oos = new ObjectOutputStream(socket.getOutputStream());
         
         System.out.println("Connected");
         
         carIndex = (Integer)ois.readObject();
         System.out.println("Car ID: " + carIndex);
      }
      catch(ClassNotFoundException cnfe){
         System.out.println("ClassNotFoundException 2: " + cnfe);
      }
      catch(UnknownHostException uhe){
         System.out.println("UnknownHostException: " + uhe);
      }
      catch(IOException ioe){
         System.out.println("IOException 1: " + ioe);
      }
      
      Location loc = new Location();
      loc.start();
   }
   
   /**
    * Location class
    * Sends the location of a car to each client
   */
   class Location extends Thread{
   
      public void run(){
         try{
            while(true){
               Object obj = ois.readObject();
               
               CarPosition pos = (CarPosition)obj;
               System.out.println(pos);
               
               int carPos = pos.getCarId();
               
               for(int i = 0;i < arrayCars.size();i++){
                  if(arrayCars.get(i).carId == carPos){
                     arrayCars.get(i).racePosX = pos.getPosX();
                     arrayCars.get(i).racePosY = pos.getPosY();
                     arrayCars.get(i).raceROT = pos.getRot();
                  }
               }
            }
         }
         catch(ClassNotFoundException cnfe){
            System.out.println("ClassNotFoundException 3: " + cnfe);
         }
         catch(IOException ioe){
            System.out.println("IOException 2: " + ioe);
         }
      }
      
   } // End Location sub-class
   
   /*
    * XML Settings class
    * Handles game settings
   */
   class XMLSettings{
   
      // Game property
      public String serverIP = "127.0.0.1";
      public int serverPort = 3000;
      
      // General for this class
      private String xmlFilePath = "";
      
      // Constructor
      public XMLSettings(String filePath){
         this.xmlFilePath = filePath;
      }
      
      /*
       * Write xml method
       * Writes the xml file
      */
      public void writeXML(){
         try{
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            
            // Root element
            Element rootElement = doc.createElement("GameSettings");
            doc.appendChild(rootElement);
            
            // Socket element
            Element socket = doc.createElement("Socket");
            rootElement.appendChild(socket);
            
            // Add IP and PORT
            Element port = doc.createElement("port");
            port.appendChild(doc.createTextNode(this.serverPort + ""));
            socket.appendChild(port);
            Element serverIP = doc.createElement("serverIP");
            serverIP.appendChild(doc.createTextNode(this.serverIP + ""));
            socket.appendChild(serverIP);
            
            // Write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(xmlFilePath));
            transformer.transform(source, result);
            
            // Output to console for testing
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);
         }
         catch(ParserConfigurationException pce){
            System.out.println("ParserConfigurationException 1: " + pce);
         }
         catch (Exception e){
            e.printStackTrace();
         }
      }
      
      /*
       * Read xml method
       * Reads the xml file
      */
      public void readXML(){
         try{
            DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = dbfactory.newDocumentBuilder();
            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath path = xpfactory.newXPath();
            
            File f = new File(this.xmlFilePath);
            Document doc = builder.parse(f);
            
            this.serverPort = Integer.parseInt(path.evaluate(
                  "/GameSettings/Socket/port", doc));
                  
            this.serverIP = path.evaluate(
                  "/GameSettings/Socket/serverIP", doc);
         
            System.out.println("Read XML: Server IP - " + this.serverIP + ", Server port - " + this.serverPort);  
         }
         catch(ParserConfigurationException pce){
             System.out.println("ParserConfigurationException 2: " + pce);
         }
         catch(XPathExpressionException xpee){
            System.out.println("XPathExpressionException 1: " + xpee);
         }
         catch(SAXException saxe){
            System.out.println("SAXException 1: " + saxe);
         }
         catch(IOException ioe){
            System.out.println("IOException 3: " + ioe);
         }
      }
   
   } // End of XML class
   
} // end class Races